# Business Email and Report Manager

**Agentic AI Bootcamp — atomcamp | Weekly Project**

A complete AI-powered business communication and reporting assistant built with the
Groq API (free tier). The assistant uses `llama-3.3-70b-versatile` with function
calling to intelligently select and chain tools before generating output.

---

## Features

| # | Feature | Description |
|---|---------|-------------|
| 1 | Smart Email Writer | Drafts professional emails in formal, professional, or friendly tone. Can research market context via web search before writing. |
| 2 | Report Generator | Creates structured business reports from numeric data with computed metrics, trend analysis, and recommendations. |
| 3 | Meeting Summarizer | Converts raw meeting notes into structured summaries with key points, decisions, and action items. |
| 4 | Business Data Analyzer | Answers natural language questions about sales, revenue, or any numeric dataset. |
| 5 | Client Communication Drafter | Creates proposals, status updates, follow-up messages, and responses for clients. |

## Tools

| # | Tool | Description |
|---|------|-------------|
| 1 | Calculator | Safely evaluates financial expressions — percentages, growth rates, compound interest. |
| 2 | Web Search | Mock search returning realistic business and market data (replaceable with SerpAPI or Tavily). |
| 3 | Data Analyzer | Computes sum, average, max, min, median, std deviation, trend, and growth rate for any dataset. |
| 4 | Report Formatter | Returns structured report templates with section headers and KPI labels for each report type. |

---

## Requirements

- Python 3.9 or higher
- A free Groq API key — get one at https://console.groq.com

---

## Installation

```bash
# 1. Clone the repository
git clone https://github.com/your-username/business-assistant.git
cd business-assistant

# 2. Install dependencies
pip install -r requirements.txt

# 3. Set up your API key
cp .env.example .env
# Open .env and replace the placeholder with your real key
```

---

## Usage

### Run the interactive CLI

```bash
python business_assistant.py
```

The menu lets you access all five features step by step.

### Use the API directly in your own script

```python
import os
from dotenv import load_dotenv
from business_assistant import BusinessAssistant

load_dotenv()
assistant = BusinessAssistant(api_key=os.environ["GROQ_API_KEY"])

# Feature 1: Write an email
print(assistant.write_email(
    purpose="Announce Q2 sales results to our investors",
    recipient="stakeholder",
    tone="formal"
))

# Feature 2: Generate a report
data = {"Jan": 50000, "Feb": 65000, "Mar": 80000}
print(assistant.generate_report("quarterly", data, "Q1 2026"))

# Feature 3: Summarize a meeting
notes = "Discussed Q3 roadmap. Budget approved at 500k. Sara leads campaign. Next meeting June 5."
print(assistant.summarize_meeting(notes, date="May 22, 2026"))

# Feature 4: Analyze business data
print(assistant.analyze_business_data(
    "What is the average revenue and overall growth rate?",
    data
))

# Feature 5: Draft a client communication
print(assistant.draft_client_communication(
    comm_type="proposal",
    client="NexaTech Solutions",
    context="ERP implementation, 4-month timeline, PKR 2.5M budget",
    tone="professional"
))
```

---

## File Structure

```
business-assistant/
├── business_assistant.py   Main program and interactive CLI
├── tools.py                Tool functions and Groq tool schemas
├── requirements.txt        Python dependencies
├── .env.example            API key template
├── README.md               This file
├── examples/
│   ├── email_examples.txt
│   ├── report_examples.txt
│   └── meeting_examples.txt
└── tests/
    └── test_features.py    Unit and integration tests
```

---

## Running Tests

```bash
# Run all tests (GROQ_API_KEY must be set for integration tests)
python -m pytest tests/test_features.py -v

# Run only unit tests — no API key needed
python -m pytest tests/test_features.py -v -m unit

# Run only integration tests
python -m pytest tests/test_features.py -v -m integration

# Show print output during tests (useful to see tool call logs)
python -m pytest tests/test_features.py -v -s
```

The test file covers:
- 40+ unit tests for all four tool functions (no API required)
- Input validation and error handling edge cases
- Integration tests for all five assistant features (requires API key)

---

## Environment Variables

| Variable | Description |
|----------|-------------|
| `GROQ_API_KEY` | Your Groq API key (required) |

---

## Getting a Free Groq API Key

1. Go to https://console.groq.com
2. Sign up for a free account
3. Navigate to **API Keys** and create a new key
4. Copy the key into your `.env` file

---

## Notes

- The web search tool is a mock by default. To use real search results, replace the `web_search` function in `tools.py` with a call to SerpAPI, Tavily, or the Brave Search API.
- All tool functions return JSON strings so they integrate directly with the Groq function-calling protocol.
- The assistant uses an agentic loop with a safety limit of 8 iterations per request.

---

*Built for atomcamp Agentic AI Bootcamp — Weekly Project Assignment*
